<?php

/**
 * Cette classe permet d'avoir le numéro de version dde Roundcube Melanie2
 *
 * @author PNE Messagerie/Apitech
 * @package Librairie Mélanie2
 */
class Version {

    /**
     * Numéro de version
     */
    const VERSION = '0.5.8';
   
    /**
     * Build
     */
    const BUILD = '20170109155552';

}
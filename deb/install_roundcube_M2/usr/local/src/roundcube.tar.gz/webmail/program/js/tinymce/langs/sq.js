tinymce.addI18n('sq',{
"Special character": "Karakter i veqant",
"Source code": "Kodi burimor",
"Color": "Ngjyra",
"Right to left": "Nga e djathta n\u00eb t\u00eb majt\u00eb",
"Left to right": "Nga e majta n\u00eb t\u00eb djatht\u00eb",
"Horizontal line": "Vij\u00eb horizontale"
});
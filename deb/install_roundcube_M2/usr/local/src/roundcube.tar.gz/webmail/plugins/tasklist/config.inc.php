<?php

$rcmail_config['tasklist_driver'] = 'mce';


﻿<?php
$rcmail_config['applications_list'] = array("version" => 2, "button-mce_jabber", "button-tasklist", "button-mce_sondage", "button-mce_owncloud", "button-melanissimo", "button-alfresco", "button-jitsi", "button-mce_anaisweb");
$rcmail_config['applications_ignore'] = array("button-mce_applications");
$rcmail_config['others_applications'] = array(
    array(
        "name" => "Melanissimo",
        "internal_url" => "https://melanissimo.din.developpement-durable.gouv.fr",
        "external_url" => "https://melanissimo.developpement-durable.gouv.fr",
        "internal_icon" => "./plugins/mce_applications/apps_images/app-logo_melanissimo.png",
        "external_icon" => "./plugins/mce_applications/apps_images/app-logo_melanissimo.png",
    ),
    array(
        "name" => "Alfresco",
        "internal_url" => "https://travail-collaboratif.developpement-durable.gouv.fr",
        "external_url" => "",
        "internal_icon" => "./plugins/mce_applications/apps_images/app-logo_alfresco.png",
        "external_icon" => "",
    ),
		array(
				"name" => "Jitsi",
				"internal_url" => "https://webconf.rie.gouv.fr/accueil/",
				"external_url" => "",
				"internal_icon" => "./plugins/mce_applications/apps_images/app-logo_jitsi.png",
				"external_icon" => "",
		),
);
<?php
$rcmail_config['sondage_url'] = 'https://ip-84-39-52-52.rev.cloudwatt.com/pegase/';
$rcmail_config['sondage_external_url'] = 'https://ip-84-39-52-52.rev.cloudwatt.com/pegase/';
$rcmail_config['sondage_create_sondage_url'] = 'https://ip-84-39-52-52.rev.cloudwatt.com/pegase/?_p=edit&_a=new';

<?php
/**
 * Ce fichier fait parti de l'application de sondage du MEDDE/METL
* Cette application est un doodle-like permettant aux utilisateurs
* d'effectuer des sondages sur des dates ou bien d'autres criteres
*
* L'application est crite en PHP5,HTML et Javascript
* et utilise une base de donnes postgresql et un annuaire LDAP pour l'authentification
*
* @author Thomas Payen
* @author PNE Annuaire et Messagerie
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU Affero General Public License as
* published by the Free Software Foundation, either version 3 of the
* License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU Affero General Public License for more details.
*
* You should have received a copy of the GNU Affero General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*/
namespace Config;

/**
 * Classe de configuration des serveurs LDAP
 *
 * @package Config
 */
class Ldap {
	/**
	 * Configuration du choix de serveur utilis pour l'authentification
	 * @var string
	 */
	public static $AUTH_LDAP = "ldapmaster-srv.mce.com";
	/**
	 * Configuration du choix de serveur utilis pour la recherche dans l'annuaire
	 * @var string
	 */
	public static $SEARCH_LDAP = "ldapmaster-srv.mce.com";
	/**
	 * Configuration du choix de serveur utilis pour l'autocompltion
	 * @var string
	 */
	public static $AUTOCOMPLETE_LDAP = "ldapmaster-srv.mce.com";

	/**
	 * Configuration des serveurs LDAP
	 * Chaque cl indique le nom du serveur ldap et sa configuration de connexion
	 * hostname, port, dn
	 * informations
	 */
	public static $SERVERS = array(
			/* Serveur LDAP IDA de test */
			"ldapmaster-srv.mce.com" => array(
					/* Host vers le serveur d'annuaire, prcd par ldaps:// si connexion SSL */
					"hostname" => "ldap://ldapmaster-srv.mce.com",
					/* Port de connexion au LDAP */
					"port" => 389,
					/* Base DN de recherche */
					"base_dn" => "ou=boites,ou=mce,o=gouv,c=fr",
					/* Base de recherche pour les objets de partage */
					"shared_base_dn" => "ou=boites,ou=mce,o=gouv,c=fr",
					/* Version du protocole LDAP */
					"version" => 3,
					/* Connexion TLS */
					"tls" =>  false,
					// Configuration des attributs et filtres de recherche
					// Filtre de recherche pour la mthode get user infos
                                         "get_user_infos_filter" => "(uid=%%username%%)",
                                        // Liste des attributs  rcuprer pour la mthode get user infos
                                        "get_user_infos_attributes" =>  array('cn', 'mail', 'uid', 'mailhost'),
                                        // Filtre de recherche pour la mthode get user infos from email
                                        "get_user_infos_from_email_filter" => "(mail=%%email%%)",
                                        // Liste des attributs  rcuprer pour la mthode get user infos from email
                                        "get_user_infos_from_email_attributes" => array('cn', 'mail', 'uid', 'mailhost'),

			),
	);
}

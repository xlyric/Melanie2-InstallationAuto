<?php

/**
 * Ce fichier fait parti de l'application de sondage du MEDDE/METL
 * Cette application est un doodle-like permettant aux utilisateurs
 * d'effectuer des sondages sur des dates ou bien d'autres criteres
 *
 * L'application est crite en PHP5,HTML et Javascript
 * et utilise une base de donnes postgresql et un annuaire LDAP pour l'authentification
 *
 * @author Thomas Payen
 * @author PNE Annuaire et Messagerie
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
namespace Config;

/**
 * Configuration de la connexion SQL vers la base de donnes Mlanie2
 *
 * @package Config
 */
class Sql {
  /**
   * Configuration du choix de serveur utilis pour la lecture dans la base de donnes
   *
   * @var string
   */
  public static $READ_SERVER = "pegasedb-srv.mce.com";
  /**
   * Configuration du choix de serveur utilis pour l'criture dans la base de donnes
   *
   * @var string
   */
  public static $WRITE_SERVER = "pegasedb-srv.mce.com";
  /**
   * Configuration de la connexion SQL
   *
   * @var array
   */
  public static $SERVERS = array(
          "pegasedb-srv.mce.com" => array(
                  /**
                   * Connexion persistante
                   */
                  'persistent' => 'true',
                  /**
                   * Le Data Source Name (DSN) de PDO
                   */
                  'dsn' => null,
                  /**
                   * Hostname ou IP vers le serveur SGBD
                   */
                  'hostspec' => "pegasedb-srv.mce.com",
                  /**
                   * Utilisateur pour la connexion  la base
                   */
                  'username' => "pegase",
                  /**
                   * Mot de passe pour l'utilisateur
                   */
                  'password' => "pegase",
                  /**
                   * Base de donnes Mlanie
                   */
                  'database' => "pegase",
                  /**
                   * Port de connexion
                   */
                  'port' => 5432,
                  /**
                   * Protocole de connexion
                   */
                  'protocol' => 'tcp',
                  /**
                   * Encodage de la base de donnes
                   */
                  'charset' => 'utf-8',
                  /**
                   * Type de base : pgsql, mysql
                   */
                  'phptype' => "pgsql"
          )
  );
}

<?php
/**
 * Ce fichier fait parti de l'application de sondage du MEDDE/METL
 * Cette application est un doodle-like permettant aux utilisateurs
 * d'effectuer des sondages sur des dates ou bien d'autres criteres
 *
 * L'application est crite en PHP5,HTML et Javascript
 * et utilise une base de donnes postgresql et un annuaire LDAP pour l'authentification
 *
 * @author Thomas Payen
 * @author PNE Annuaire et Messagerie
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
namespace Config;

/**
 * Configuration de l'ihm pour l'application de sondage
 *
 * @package Config
 */
class IHM {
  /**
   * Configuration de la localization par dfaut
   */
  public static $DEFAULT_LOCALIZATION = "fr_FR";
  /**
   * Configuration de l'overlay pour la localization
   */
  public static $OVERLAY_LOCALIZATION = "_melanie2";
  
  /**
   * Doit-on afficher la page de maintenance ?
   */
  public static $MAINTENANCE = false;

   /**
   * Access via cerbere
   */
  public static $USE_CERBERE = false;

	/**
	 * Configuration du nom de la skin  utiliser pour l'ihm
	 */
	public static $SKIN = 'default';
	/**
	 * Configuration du nom de l'application
	 */
	public static $TITLE = 'Pegase';
	/**
	 * Permettre la cration de l'utilisateur depuis l'interface
	 * Le driver doit prendre en compte la cration de l'utilisateur avec un mot de passe crypt
	 */
	public static $CREATE_USER = false;

	/**
	 * Nombre de rponses ncessaires avant l'affichage du pop de verrouillage
	 * @var int
	 */
	public static $POPUP_NB_RESPONSES = 2;
	/**
	 * Temps entre la cration du sondage et l'affichage du pop up pour le verrouillage
	 * En secondes
	 * @var int
	 */
	public static $POPUP_TIME_CREATED = 60;

	/**
	 * Configuration du timezone par defaut pour l'application
	 */
	public static $DEFAULT_TIMEZONE = 'Europe/Paris';
	/**
	 * Type de stockage pour les sessions, 'php' ou 'memcache'
	 */
	//public static $SESSION_TYPE = 'memcache';
	public static $SESSION_TYPE = 'php';
	/**
	 * Dure de vie des sessions en minutes
	 */
	public static $SESSION_LIFETIME = 4320;
	//public static $SESSION_LIFETIME = 1;
	/**
	 * Cl de stockage du mot de passe en session
	 */
	public static $SESSION_PASSWORD = 'survpwdencr';
	/**
	 * Cl de stockage du login utilisateur en session
	 */
	public static $SESSION_USERNAME = 'username';
	/**
	 * Cl de stockage du token de validation session
	 */
	public static $SESSION_TOKEN = 'survtoken';
	/**
	 * Cl de stockage du token de validation session en cookie
	 */
	public static $COOKIE_TOKEN = 'survuniqid';
	/**
	 * Cl de stockage du token de validation CSRF en session
	 */
	public static $CSRF_TOKEN = 'survcsrf_token';
	/**
	 * Host du serveur dans le cas ou il n'est pas rcuprable facilement
	 * [Optionnel] Peut tre mis  null
	 */
          public static $HOST = null;
	/**
	 * URL vers la page de login, peut tre change pour l'annuaire fdrateur
	 * [Optionnel] Peut tre mis  null
	 */
	 public static $LOGIN_URL = null;
	/**
	 * Utiliser un SSO pour se connecter  Pgase
	 * Dans ce cas la page de login est limite
	 * @var boolean
	 */
	public static $USE_SSO = false;
	/**
	 * Dfini la valeur du champ get pour lui passer une url en redirection
	 * [Optionnel] Peut tre mis  null
	 */
	public static $GET_URL = null;
	/**
	 * Liste des types de sondage possible
	 */
	public static $POLL_TYPES = array("date", "prop");
	/**
	 * Configuration du ou des serveurs memcache
	 */
	public static $MEMCACHE_SERVER = array('pegaseapp-srv.mce.com:11211');

	/**
	 * URL de disponibilit des utilisateurs
	 * Peut tre configur dans le ldap ou ici (la valeur du ldap prend le dessus)
	 *
	 * Paramtres possible: %%username%% / %%email%%
	 *
	 * @var string
	 */
       
	 public static $FREEBUSY_URL = "https://ip-84-39-52-52.rev.cloudwatt.com/kronolith/fb.php?u=%%username%%";
	/**
	 * Dfini si les tentatives supprims par l'organisateur (validation d'une date, suppression du sondage)
	 * sont rpercutes pour tous les participants
	 * @var boolean
	 */
	public static $ORGANIZER_DELETE_TENTATIVES_ATTENDEES = true;

	/**
	 * Valeur de header pour le Access-Control-Allow-Origin
	 * Permet d'effectuer une authentification cross domain depuis Roundcube
	 */
	 public static $ROUNDCUBE_CORS = "https://ip-84-39-52-52.rev.cloudwatt.com/webmail/";
	
       /**
	 * Dfini si l'application doit envoyer des mails
	 * @var boolean
	 */
	public static $SEND_MAIL = true;
	/**
	 * Adresse mail utilise pour envoyer les email de notification aux utilisateurs
	 */
	public static $FROM_MAIL = "test1@mce.com";

	/**
	 * Cl DES utilise pour l'encodage du mot de passe en session
	 * this key is used to encrypt the users imap password which is stored
     * in the session record (and the client cookie if remember password is enabled).
     * please provide a string of exactly 24 chars.
     * YOUR KEY MUST BE DIFFERENT THAN THE SAMPLE VALUE FOR SECURITY REASONS
	 */
	public static $DES_KEY = 'survey-.22TifhRGHset$Tri';
}

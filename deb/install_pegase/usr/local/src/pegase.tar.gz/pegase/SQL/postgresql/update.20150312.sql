ALTER TABLE users ADD COLUMN password varchar(255);

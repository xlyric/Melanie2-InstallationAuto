ALTER TABLE responses ADD COLUMN settings text DEFAULT ''::text NOT NULL;

dokielMgr.fStrings = ["Pas à pas","Afficher les étapes une à une",          //00
                      "Retour","Retourner au contenu",                      //02
                      "précédent","étape précédente",                       //04
                      "suivant","étape suivante",                           //06
                      "Etape : ","",                                          //08
                      "Liste","Afficher les zones en liste",                //10
                      "Info-bulles","Afficher les zones en info-bulles",    //12
                      "",""];                                                   //

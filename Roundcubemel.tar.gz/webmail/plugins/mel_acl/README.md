Plugin mel_acl
==============

INTRODUCTION
------------
Plugin mel_acl is used to manage the acl for mailboxes, calendars, addressbooks and tasklists. Each user can add show/read/write rights for his data.

DEPENDANCES
-----------
This plugin needs the [Mél ORM][orm], the [mel][mel] plugin and the [mel_logs][mel_logs] plugin


[orm]:          		https://github.com/messagerie-melanie2/ORM-M2
[mel]:					https://github.com/messagerie-melanie2/Roundcube-plugins-Mel/tree/master/plugins/mel
[mel_logs]: 			https://github.com/messagerie-melanie2/Roundcube-plugins-Mel/tree/master/plugins/mel_logs
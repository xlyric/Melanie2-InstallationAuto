// Nettoyage des localstorages
window.localStorage.removeItem('right_panel.cache');
window.localStorage.removeItem('right_panel.event');
window.localStorage.removeItem('right_panel.contactsList');
window.localStorage.removeItem('ariane_user_status');
window.localStorage.removeItem('rocket_chat_title');